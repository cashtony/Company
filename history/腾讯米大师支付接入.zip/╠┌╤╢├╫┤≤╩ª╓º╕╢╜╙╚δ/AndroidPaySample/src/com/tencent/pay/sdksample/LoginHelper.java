package com.tencent.pay.sdksample;

import oicq.wlogin_sdk.request.WtloginHelper;
import android.content.Context;


public class LoginHelper extends WtloginHelper { 
	
	public LoginHelper(Context context){
		super(context);
	}
} 