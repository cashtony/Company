/** Automatically generated file. DO NOT MODIFY */
package com.tencent.pay.sdksample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}